#include <stdio.h>
#include "print.h"
 
int Add (int a, int b)
{
     return a + b ;
}

int Sub (int a, int b)
{
     return a - b ;
}
 
 