#ifndef _PRINT_H_
#define _PRINT_H_
 
int Add(int a , int b);
int Sub(int a , int b);
 
#endif