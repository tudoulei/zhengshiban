package com.hauweicloud;

import com.sun.jna.Library;
import com.sun.jna.Native;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Scanner;

public class PrintInfo {

    public static void main(String[] args) throws Exception {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Please enter the host name");
        String s = scanner.nextLine();
        String md5 = getStrMD5(s);
        System.out.println("=================================");
        char cfirst = md5.charAt(0);
        char clast = md5.charAt(md5.length() - 1);
		int numFirst = cfirst;
		int numLast = clast;
		if(cfirst >= '0' && cfirst <='9')
		{
			numFirst = Integer.valueOf(Character.toString(cfirst));
		}
		
		if(clast >= '0' && clast <='9')
		{
			numLast = Integer.valueOf(Character.toString(clast));
		}
		
        System.out.println(md5);
        System.out.println(cfirst+"+"+clast+"="+add(numFirst,numLast));
    }

    public interface CLibrary extends Library {
        CLibrary INSTTANCE = (CLibrary) Native.loadLibrary("print", CLibrary.class);
        int Add(int a, int b);
        int Sub(int a, int b);
    }

    public static int add(int a, int b) {
        return CLibrary.INSTTANCE.Add(a, b);
    }
    public static int sub(int a, int b) {
        return CLibrary.INSTTANCE.Sub(a, b);
    }

    public static String getStrMD5(String str) {
        MessageDigest md5 = null;

        try {
            md5 = MessageDigest.getInstance("MD5");
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
            System.out.println(e.toString());
            return "Get MD5 instance exception";
        }

        char[] charArray = str.toCharArray();
        byte[] byteArray = new byte[charArray.length];
        for (int i = 0; i < charArray.length; i++)
            byteArray[i] = (byte) charArray[i];
        byte[] digest = md5.digest(byteArray);
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < digest.length; i++) {
            int var = digest[i] & 0xff;
            if (var < 16)
                sb.append("0");
            sb.append(Integer.toHexString(var));
        }
        return sb.toString();
    }
}
